# 客服与邮件回复｜练习包

[完整教程](../../tutorials/chatgpt-email-customer-replies.md) · [全部练习](../../README.md)

材料均为原创虚构练习。先阅读教程，再按顺序使用输入与提示词；代码只在自己确认的本地练习目录运行。

## 先怎样使用

01是完整虚构来信与规则；02用于起草回复。只生成草稿，不发送；不把此例当真实售后条款。

| 文件 | 用途 |
|---|---|
| [01-prompt-or-input.txt](01-prompt-or-input.txt) | 从正文完整提取的输入、提示词或参考代码 |
| [02-prompt-or-input.txt](02-prompt-or-input.txt) | 从正文完整提取的输入、提示词或参考代码 |
| [expected-result.md](expected-result.md) | 参考答案与检查重点 |

## 完成后检查

资料已收到，仍待人工核对；检查资料齐全后回复进度。不承诺今天完成，不编造延迟原因。这是虚构材料，不是小小AI实际订单政策。

GitHub文件页可以使用Raw或下载入口；也可在资源总页下载合集。
