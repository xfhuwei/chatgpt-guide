# 代码审查与测试｜练习包

[完整教程](../../tutorials/chatgpt-code-review-testing.md) · [全部练习](../../README.md)

材料均为原创虚构练习。先阅读教程，再按顺序使用输入与提示词；代码只在自己确认的本地练习目录运行。

## 先怎样使用

01-reference.py包含参考函数；按正文的六组输入分别调用，检查普通、满员、超额和非法输入。其他文本文件是审查请求。

| 文件 | 用途 |
|---|---|
| [01-reference.py](01-reference.py) | 从正文完整提取的输入、提示词或参考代码 |
| [02-prompt-or-input.txt](02-prompt-or-input.txt) | 从正文完整提取的输入、提示词或参考代码 |
| [expected-result.md](expected-result.md) | 参考答案与检查重点 |

## 完成后检查

容量20：[8,6,4]剩2，[10,10]剩0，[10,8,5]剩-3，空列表剩20；负数或True人数拒绝。

GitHub文件页可以使用Raw或下载入口；也可在资源总页下载合集。
